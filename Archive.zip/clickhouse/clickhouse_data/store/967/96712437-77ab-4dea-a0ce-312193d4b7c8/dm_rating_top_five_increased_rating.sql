ATTACH TABLE _ UUID 'edbc7fd3-84ef-4b21-8ae7-79429ed1c655'
(
    `label` String,
    `movie` String,
    `year_month` String
)
ENGINE = MergeTree
ORDER BY year_month
SETTINGS index_granularity = 8192
