ATTACH TABLE _ UUID 'ea545586-74c0-48dc-b3d8-0144b2e9e470'
(
    `test` String
)
ENGINE = MergeTree
ORDER BY tuple()
SETTINGS index_granularity = 8192
