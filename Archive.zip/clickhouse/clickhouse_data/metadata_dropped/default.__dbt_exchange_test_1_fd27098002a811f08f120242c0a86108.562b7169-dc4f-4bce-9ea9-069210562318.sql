ATTACH TABLE _ UUID '562b7169-dc4f-4bce-9ea9-069210562318'
(
    `test` String
)
ENGINE = MergeTree
ORDER BY tuple()
SETTINGS index_granularity = 8192
