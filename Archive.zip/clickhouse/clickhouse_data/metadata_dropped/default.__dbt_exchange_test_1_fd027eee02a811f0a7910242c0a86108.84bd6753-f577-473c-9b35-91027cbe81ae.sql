ATTACH TABLE _ UUID '84bd6753-f577-473c-9b35-91027cbe81ae'
(
    `test` String
)
ENGINE = MergeTree
ORDER BY tuple()
SETTINGS index_granularity = 8192
