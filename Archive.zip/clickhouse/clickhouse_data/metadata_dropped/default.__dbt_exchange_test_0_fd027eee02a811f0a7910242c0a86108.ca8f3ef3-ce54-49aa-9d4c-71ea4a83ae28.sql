ATTACH TABLE _ UUID 'ca8f3ef3-ce54-49aa-9d4c-71ea4a83ae28'
(
    `test` String
)
ENGINE = MergeTree
ORDER BY tuple()
SETTINGS index_granularity = 8192
