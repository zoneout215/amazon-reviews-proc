ATTACH TABLE _ UUID 'ec73d696-d96a-4222-85cd-5134082069d4'
(
    `test` String
)
ENGINE = MergeTree
ORDER BY tuple()
SETTINGS index_granularity = 8192
