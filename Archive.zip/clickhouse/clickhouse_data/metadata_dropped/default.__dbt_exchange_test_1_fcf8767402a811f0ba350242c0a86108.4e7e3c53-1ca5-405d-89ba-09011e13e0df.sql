ATTACH TABLE _ UUID '4e7e3c53-1ca5-405d-89ba-09011e13e0df'
(
    `test` String
)
ENGINE = MergeTree
ORDER BY tuple()
SETTINGS index_granularity = 8192
